import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'main.dart';

class logout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Logout'),
        ),
        body: Center(
          child: Container(
              child: Column(children: [
            SizedBox(
              height: 230,
            ),
            Text('Thankyou for choosing Creative Solution Sdn Bhd!!'),
            Text('Enjoy with this Apps!!'),
          ])),
        ));
  }
}
