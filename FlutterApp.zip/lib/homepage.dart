import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:login_signup/main.dart';
import 'package:login_signup/managerHome.dart';
import 'manager.dart';
import 'package:login_signup/home_staff.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  MyHomePage createState() => MyHomePage();
}

class MyHomePage extends State {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //application name
      title: 'Assignment Group',
      theme: ThemeData(
        primarySwatch: Colors.grey,
      ),
      home: Scaffold(
        appBar: AppBar(centerTitle: true, title: Text('Home Page')),
        body: Container(
            alignment: Alignment.center,
            child: Column(children: <Widget>[
              Padding(padding: EdgeInsets.all(10)),
              Text('Welcome !!',
                  style: TextStyle(
                    fontSize: 19.0,
                  )),
              Padding(padding: EdgeInsets.all(50)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => MyManager()));
                },
                child: Text('Manager'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              Padding(padding: EdgeInsets.all(50)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: ((context) => MyStaff())));
                },
                child: Text('Staff'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ])),
      ),
    );
  }
}
