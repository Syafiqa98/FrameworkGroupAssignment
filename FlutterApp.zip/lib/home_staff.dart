import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:login_signup/logout.dart';
import 'update_page.dart';
import 'register_page.dart';

void main() {
  runApp(MyStaff());
}

class MyStaff extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: StaffHome(),
    );
  }
}

class StaffHome extends StatefulWidget {
  MyHomeStaffPage createState() => MyHomeStaffPage();
}

class MyHomeStaffPage extends State {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        //application name
        title: 'Assignment Group',
        theme: ThemeData(
          primarySwatch: Colors.grey,
        ),
        home: Scaffold(
          appBar: AppBar(centerTitle: true, title: Text('Staff')),
          body: Container(
              alignment: Alignment.center,
              child: Column(children: <Widget>[
                Padding(padding: EdgeInsets.all(50)),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: ((context) => RegisterPage())));
                  },
                  child: Text('Register New Fleet'),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(50)),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => UpdatePage()));
                  },
                  child: Text('Update Status Fleet'),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                Padding(padding: EdgeInsets.all(50)),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: ((context) => logout())));
                  },
                  child: Text('Logout'),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                )
              ])),
        ));
  }
}
