import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class manager extends StatefulWidget {
  @override
  _TablesState createState() => _TablesState();
}

class _TablesState extends State<manager> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fleets Details"),
      ),
      body: Column(children: <Widget>[
        Text(
          "Table Details Fleets",
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 25),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 30),
        ),
        Text(
          "Fleets record:",
          textAlign: TextAlign.start,
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 25),
        ),
        Table(
          border: TableBorder.all(
            width: 0.5,
            color: Colors.black,
          ),
          children: [
            TableRow(children: [
              Text("Name"),
              Text("Register Date"),
              Text("Location"),
              Text("Status")
            ]),
            TableRow(children: [
              Text("Transport"),
              Text("05.09.2022"),
              Text("Sabah"),
              Text("Active")
            ]),
            TableRow(children: [
              Text("Delivery"),
              Text("10.08.2022"),
              Text("Sarawak"),
              Text("Active"),
            ]),
            TableRow(children: [
              Text("Commercial"),
              Text("27.11.2022"),
              Text("Kedah"),
              Text("Inactive")
            ]),
            TableRow(children: [
              Text("Transport"),
              Text("11.12.2022"),
              Text("Kelantan"),
              Text("Active")
            ]),
          ],
        ),
      ]),
    );
  }
}
